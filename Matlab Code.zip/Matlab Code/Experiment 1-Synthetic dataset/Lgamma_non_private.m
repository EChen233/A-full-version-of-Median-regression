function f = Lgamma_non_private( beta,X,Y,lambda)
%global n X Y lambda gamma;
%自变量是beta
n = length(Y);
r = beta(1)+X*beta(2:4)-Y;
rho = abs(r);


beta1 = beta(2:4);
%扰动后的目标函数
 f = sum(rho)/length(r)+lambda/2*(beta1'*beta1);
end

