function [f,g] = Lgamma( beta,b,X,Y,lambda,gamma)
%global n X Y lambda gamma;
%自变量是beta
n = length(Y);
r = beta(1)+X*beta(2:4)-Y;
rho = zeros(length(r),1);
for i=1:length(r)
if abs(r(i))<=gamma
     rho(i) = r(i)^2/2/gamma;
 else
   rho(i) = abs(r(i))-2*gamma;
end
end
beta1 = beta(2:4);
%扰动后的目标函数
 f = sum(rho)/length(r)+b'/length(r)*beta+lambda/2*beta1'*beta1+beta(1)^2/sqrt(length(r));
s = zeros(length(r),1);
 for i=1:length(r)
if r(i)<-gamma
     s(i) = -1;
elseif r(i)>gamma
   s(i) =1;
else 
    s(i) = 0;
end
 end
w = 1-s.^2;
i1=1:n;
j1=1:n;
W = sparse(i1,j1,w);
XD = [ones(n,1),X];    
g = 1/n*XD'*(1/gamma*W*r+s)+b/n+lambda*[0;beta(2:4)]+[beta(1);0;0;0]/sqrt(n);

% r = beta(1)+x*beta(2:4)'-y;
% if abs(r)<=gamma;
%     rho = r^2/2/gamma;
% else
%     rho = abs(r)-2*gamma;
% end
% out=rho;
end

