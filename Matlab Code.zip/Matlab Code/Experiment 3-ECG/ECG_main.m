
 %global n X Y lambda gamma;
 data = readtable('ECG_person_01_rec_7.xlsx');
 gamma=0.05;
 lambda = 0;
 %X = Time(1:5000);        %take 'ms' as the unit
 %Y = mVraw(1:5000);
 X = table2array(data(:,1));
 Y = table2array(data(:,2));
 n=length(Y);
 T = 10/12;
 omega = 2*pi/T;
 XD = [ones(n,1),cos(1*omega*X), sin(1*omega*X),cos(2*omega*X), sin(2*omega*X),...
     cos(3*omega*X), sin(3*omega*X),cos(4*omega*X), sin(4*omega*X),cos(5*omega*X), sin(5*omega*X),...
     cos(6*omega*X), sin(6*omega*X)]; %Fourier expansion with order 6
 d=12;%Number of indenpendent variables

 mu0 = zeros(d+1,1);
 sigma = eye(d+1);
 muset = [0.01,0.05,2];
 Z_cell = cell(length(muset),1);
 for mu_it = 1:length(muset)
     mu = muset(mu_it);
     R = mvnrnd (mu0, 16/mu^2*sigma);
     b = R';
     options = optimoptions('fminunc','GradObj','on'); % indicate gradient is provided
     beta_initial = rand(d+1,1);
     [xsol,fval] = fminunc(@(beta) Lgamma2(beta,b,XD,Y,lambda,gamma),beta_initial,options);
     betapinghua = xsol;
     Z = XD*betapinghua;
     Z_cell{mu_it} = Z;
 end
 downfactor =1;
for i=1:length(Z_cell)
    Z = Z_cell{i};
    plot(X(1:downfactor:end),Z(1:downfactor:end),'LineWidth',2),
    hold on
end
plot(X,Y,'Color', [0, 0, 1, 0.1]);
grid;
legend('\mu = 0.01','\mu = 0.05','\mu = 2');
xlabel('Time (s)');
ylabel('ECG signal (mV)')
 %   MAE_1(mu_it) = mean(abs(XD*betapinghua-Y))+lambda/2*betapinghua(2:end)'*betapinghua(2:end);

  

