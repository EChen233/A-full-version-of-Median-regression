data_carbon = readtable('carbon.xlsx');
gamma=0.05;
 lambda = 0.2; 
 % Set different privacy budget mu
 mu = 1; %
 MAE_SGD = zeros(100,1);
 MAE_Smooth = zeros(100,1);
 MAE_ItSq = zeros(100,1);
 for rep = 1:100
    InitialAtomicCoordinateU = table2array(data_carbon(:,3));
    CalculatedAtomicCoordinatesU = table2array(data_carbon(:,6));
    X = InitialAtomicCoordinateU;
    Y = CalculatedAtomicCoordinatesU;
    n=length(Y);
    XD = [ones(n,1),X];
    d=1;
    
    %%%%%%%%%%%%%%%%%%
    %% Algorithm 1: DP-SGD
    best_loss = 10^5;
    mu0=0.5;
    a = sqrt(exp(1)*cdf('normal',1.5*mu0,0,1)+3*cdf('normal',-0.5*mu0,0,1)-2);
    c = 1/(sqrt(2)*a);
    p=0.1;
    N0=floor((1/p*c)^2);
    m = floor(n*p);
    yita = 0.01;  
    Xsub=cell(N0,1);
    XDsub = cell(N0,1);
    Ysub = cell(N0,1);
    for i=1:N0
        sample_seed = randsample(n,m);
        Xsub{i} = X(sample_seed,:);
        XDsub{i} = [ones(m,1),Xsub{i}];
        Ysub{i} = Y(sample_seed);
    end
    bhat{1} = (2/n*XDsub{1}'*XDsub{1}-lambda)^(-1)*2/n*XDsub{1}'*Ysub{1};
    % bhat{1} = [0;3;2;3];
    for t=1:N0-1
        r = XDsub{t+1}*bhat{t}-Ysub{t+1};
        a = Xsub{t+1};
        b=Ysub{t+1};
        pre_beta = bhat{t};
        ad = [ones(m,1),a];
        previous_loss = mean(abs(ad*pre_beta-b))+lambda/2*pre_beta(2)'*pre_beta(2);

        %grad_clip = zeros(3,1);
        gra = zeros(1,1);
        for k =1:d
            sp = zeros(m,1);
            ak = a(:,k);
            sp(r<0) = -ak(r<0);
            sp(r>0) = ak(r>0);
            sp(r==0) = abs(ak(r==0));
            temp_beta=bhat{t};
            dp = 1/m*sum(sp)+lambda*temp_beta(k+1);
            sn = zeros(m,1);
            ak = a(:,k);
            sn(r<0) = ak(r<0);
            sn(r>0) = -ak(r>0);
            sn(r==0) = -abs(ak(r==0));
            dn = 1/m*sum(sn)+lambda*temp_beta(k+1);
            gra(k) = min(dp,dn);
            %yita = 0.2/t;
        end
        grad_clip = gra/max(1,norm(gra));    %clip
        mu1 = 0;
        sigma = 1;

        sigma0=1/mu0;
        R = mvnrnd(mu1,4*sigma0^2/m^2*sigma);
        temp_beta(2) = temp_beta(2) - yita*(grad_clip+R') ; 
        temp_beta(1) = 1/m*sum(b-a*temp_beta(2));
        temp_loss = mean(abs(XD*temp_beta-Y))+lambda/2*temp_beta(2)'*temp_beta(2);
        if temp_loss<previous_loss
            bhat{t+1} = temp_beta;
        else
            bhat{t+1} = bhat{t};
        end

        if temp_loss < best_loss
            best_loss = temp_loss;
        end
% 
    end
    betatidu = bhat{N0};
    MAE_SGD(rep) = mean(abs(XD*betatidu-Y))+lambda/2*betatidu(2)'*betatidu(2);
    %% Algorithm 2: DP-Smooth
    mu0 = [0;0];
    sigma = [1 0;0 1];
    R = mvnrnd (mu0, 16/mu^2*sigma);
    b = R';
    b = [0;0];
    options = optimoptions('fminunc','GradObj','on');
    %b = [0;0;0;0];
    beta_initial = rand(2,1);
    [xsol,fval] = fminunc(@(beta) Lgamma2(beta,b,XD,Y,lambda,gamma),beta_initial,options);
    
    betapinghua = xsol;
    MAE_Smooth(rep) = mean(abs(XD*betapinghua-Y))+lambda/2*betapinghua(2)'*betapinghua(2);

    %% Algorithm 3: DP-ItSq
    ita=100;
    bhat = cell(ita,1);
    W = speye(n);
    for i=1:ita
       bhat{i} = (2/n*XD'*W*XD-lambda)^(-1)*2/n*XD'*W*Y ; 
       r = abs(Y-XD*bhat{i});
       i1=1:n;
       j1=1:n;
       s= sqrt(1./r);
       W = sparse(i1,j1,s);
    end
    v=1;
    B=1;
    e=0.05;
    c1 = 2/(2*(sqrt(d*v)+B)+e);
    c = 12*(sqrt(d*v)+B)/(n*min(c1,lambda)*e);
    mu0=[0;0];
    sigma = [1 0;0 1];
    R = mvnrnd (mu0, c^2/mu^2*sigma);
    
    betadiedai = bhat{ita}+R'; 
    MAE_ItSq(rep) = sum(abs(Y-XD*betadiedai))/n+lambda/2*betadiedai(2)'*betadiedai(2);
end

disp('DP-SGD:');
disp(mean(MAE_SGD));
disp('DP-Smooth:');
disp(mean(MAE_Smooth));
disp('DP-ItSq:');
disp(mean(MAE_ItSq));

